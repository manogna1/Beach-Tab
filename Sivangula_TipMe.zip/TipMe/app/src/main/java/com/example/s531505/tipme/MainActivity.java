package com.example.s531505.tipme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    Double amountt,tip,total;

    public void tip20(View V){
        EditText editText=findViewById(R.id.amount);
        String amount=editText.getText().toString();
        TextView userint=findViewById(R.id.userint);
        String t="Tip is $";
        String tt="Total is $";
        try{
            amountt=Double.parseDouble(amount);
            tip=amountt*0.20;
            total=amountt+tip;
            TextView tiptv=findViewById(R.id.tipTV);
            TextView totaltv=findViewById(R.id.total);

            t+=String.format("%.2f", tip);
            tt+=String.format("%.2f", total);
            tiptv.setText(t);
            totaltv.setText(tt);
        }
catch(NumberFormatException ex){
            userint.setText("Error occured: enter only numbers");
}

    }

    public void tip15(View V){
        EditText editText=findViewById(R.id.amount);
        String amount=editText.getText().toString();
        TextView userint=findViewById(R.id.userint);
        String t="Tip is $";
        String tt="Total is $";
        try{
            amountt=Double.parseDouble(amount);
            tip=amountt*0.15;
            total=amountt+tip;
            TextView tiptv=findViewById(R.id.tipTV);
            TextView totaltv=findViewById(R.id.total);
            t+=String.format("%.2f", tip);
            tt+=String.format("%.2f", total);
            tiptv.setText(t);
            totaltv.setText(tt);
        }
        catch(NumberFormatException ex){
            userint.setText("Error occured: enter only numbers");
        }

    }

    public void tip10(View V){
        EditText editText=findViewById(R.id.amount);
        String amount=editText.getText().toString();
        TextView userint=findViewById(R.id.userint);
        String t="Tip is $";
        String tt="Total is $";
        try{

            amountt=Double.parseDouble(amount);
            tip=amountt*0.10;
            total=amountt+tip;
            TextView tiptv=findViewById(R.id.tipTV);
            TextView totaltv=findViewById(R.id.total);
            t+=String.format("%.2f", tip);
            tt+=String.format("%.2f", total);
            tiptv.setText(t);
            totaltv.setText(tt);
        }
        catch(NumberFormatException ex){
            userint.setText("Error occured: enter only numbers");
        }

    }
    public void reset(View V) {
        TextView tip = findViewById(R.id.tipTV);
        TextView amount = findViewById(R.id.total);
        EditText tipPer = findViewById(R.id.tipEt);
        tip.setText("Tip is");
        amount.setText("Total");
tipPer.setText("");

    }

    public void tipCal(View V) {

        EditText tipPer = findViewById(R.id.tipEt);
        Double tipP = Double.parseDouble(tipPer.getText().toString());
        EditText editText=findViewById(R.id.amount);
        String amount=editText.getText().toString();
        TextView userint=findViewById(R.id.userint);
        String t="Tip is $";
        String tt="Total is $";
        try{

            amountt=Double.parseDouble(amount);
            tip=(amountt*tipP)/100;
            total=amountt+tip;
            TextView tiptv=findViewById(R.id.tipTV);
            TextView totaltv=findViewById(R.id.total);
            t+=String.format("%.2f", tip);
            tt+=String.format("%.2f", total);
            tiptv.setText(t);
            totaltv.setText(tt);
        }
        catch(NumberFormatException ex){
            userint.setText("Error occured: enter only numbers");
        }
    }
}
